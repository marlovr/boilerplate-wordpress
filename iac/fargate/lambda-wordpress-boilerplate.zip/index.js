exports.handler = (event, context, callback) => {
  console.log(JSON.stringify(event));
}
